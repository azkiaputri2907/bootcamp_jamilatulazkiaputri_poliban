<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Portal Booking</title>
    <link rel="stylesheet" href="{{ asset('css/booking.css') }}">
</head>
<body>
    @yield('content')
</body>
</html>
