<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Bookings</title>
  <link rel="stylesheet" href="{{ asset('css/booking.css') }}">
</head>
<body>
  <h1>Daftar Booking Ruangan</h1>
  <div style="text-align:right; margin-bottom:20px;">
    <a href="{{ route('bookings.create') }}" class="btn-create" style="background:#3490dc;color:#fff;padding:8px 18px;border-radius:4px;text-decoration:none;">+ Tambah Booking</a>
  </div>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Nama Ruangan</th>
        <th>Nama Pengguna</th>
        <th>Keperluan</th>
        <th>Mulai</th>
        <th>Selesai</th>
        <th>Status</th>
        <th>Dibuat</th>
        <th>Diperbarui</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      @foreach($bookings as $booking)
      <tr>
        <td>{{ $booking->id }}</td>
        <td>{{ $booking->nama_ruangan }}</td>
        <td>{{ $booking->nama_pengguna }}</td>
        <td>{{ $booking->keperluan }}</td>
        <td>{{ $booking->mulai }}</td>
        <td>{{ $booking->selesai }}</td>
        <td>{{ $booking->status }}</td>
        <td>{{ $booking->created_at }}</td>
        <td>{{ $booking->updated_at }}</td>
        <td class="actions">
          <a href="{{ route('bookings.edit', $booking->id) }}" style="background:#ffc107;color:#222;padding:6px 12px;border-radius:4px;text-decoration:none;margin-right:5px;">Edit</a>
          <form action="{{ route('bookings.destroy', $booking->id) }}" method="POST" style="display:inline;">
            @csrf
            @method('DELETE')
            <button type="submit" onclick="return confirm('Yakin ingin menghapus data ini?')" style="background:#e3342f;color:#fff;padding:6px 12px;border:none;border-radius:4px;">Hapus</button>
          </form>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
</body>
</html>
