@extends('layouts.app')

@section('content')
<div class="container" style="max-width:500px;margin:40px auto;">
    <h2 style="text-align:center;">Edit Booking</h2>
    <form action="{{ route('bookings.update', $booking->id) }}" method="POST" style="margin-top:30px;">
        @csrf
        @method('PUT')
        <div style="margin-bottom:15px;">
            <label>Nama Ruangan</label>
            <input type="text" name="nama_ruangan" class="form-control" required style="width:100%;padding:8px;" value="{{ $booking->nama_ruangan }}">
        </div>
        <div style="margin-bottom:15px;">
            <label>Nama Pengguna</label>
            <input type="text" name="nama_pengguna" class="form-control" required style="width:100%;padding:8px;" value="{{ $booking->nama_pengguna }}">
        </div>
        <div style="margin-bottom:15px;">
            <label>Keperluan</label>
            <input type="text" name="keperluan" class="form-control" required style="width:100%;padding:8px;" value="{{ $booking->keperluan }}">
        </div>
        <div style="margin-bottom:15px;">
            <label>Mulai</label>
            <input type="datetime-local" name="mulai" class="form-control" required style="width:100%;padding:8px;" value="{{ date('Y-m-d\TH:i', strtotime($booking->mulai)) }}">
        </div>
        <div style="margin-bottom:15px;">
            <label>Selesai</label>
            <input type="datetime-local" name="selesai" class="form-control" required style="width:100%;padding:8px;" value="{{ date('Y-m-d\TH:i', strtotime($booking->selesai)) }}">
        </div>
        <div style="margin-bottom:15px;">
            <label>Status</label>
            <select name="status" class="form-control" required style="width:100%;padding:8px;">
                <option value="pending" @if($booking->status=='pending') selected @endif>Pending</option>
                <option value="approved" @if($booking->status=='approved') selected @endif>Approved</option>
                <option value="rejected" @if($booking->status=='rejected') selected @endif>Rejected</option>
            </select>
        </div>
        <button type="submit" style="background:#38c172;color:#fff;padding:10px 20px;border:none;border-radius:4px;">Update</button>
        <a href="{{ url('/') }}" style="margin-left:10px;">Batal</a>
    </form>
</div>
@endsection
