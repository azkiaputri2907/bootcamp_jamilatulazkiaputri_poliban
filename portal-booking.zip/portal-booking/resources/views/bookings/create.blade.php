@extends('layouts.app')

@section('content')
<div class="container" style="max-width:500px;margin:40px auto;">
    <h2 style="text-align:center;">Tambah Booking</h2>
    <form action="{{ route('bookings.store') }}" method="POST" style="margin-top:30px;">
        @csrf
        <div style="margin-bottom:15px;">
            <label>Nama Ruangan</label>
            <input type="text" name="nama_ruangan" class="form-control" required style="width:100%;padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <label>Nama Pengguna</label>
            <input type="text" name="nama_pengguna" class="form-control" required style="width:100%;padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <label>Keperluan</label>
            <input type="text" name="keperluan" class="form-control" required style="width:100%;padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <label>Mulai</label>
            <input type="datetime-local" name="mulai" class="form-control" required style="width:100%;padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <label>Selesai</label>
            <input type="datetime-local" name="selesai" class="form-control" required style="width:100%;padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <label>Status</label>
            <select name="status" class="form-control" required style="width:100%;padding:8px;">
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
            </select>
        </div>
        <button type="submit" style="background:#38c172;color:#fff;padding:10px 20px;border:none;border-radius:4px;">Simpan</button>
        <a href="{{ url('/') }}" style="margin-left:10px;">Batal</a>
    </form>
</div>
@endsection
