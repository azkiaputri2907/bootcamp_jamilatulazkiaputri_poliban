<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Portal Booking</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/booking.css')); ?>">
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\Users\pkbms\Documents\semester4kia\bootchamp\pertemuan1\portal-booking\resources\views/layouts/app.blade.php ENDPATH**/ ?>