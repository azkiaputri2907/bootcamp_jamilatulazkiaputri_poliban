

<?php $__env->startSection('content'); ?>
<div class="container" style="max-width:500px;margin:40px auto;">
    <h2 style="text-align:center;">Tambah Booking</h2>
    <form action="<?php echo e(route('bookings.store')); ?>" method="POST" style="margin-top:30px;">
        <?php echo csrf_field(); ?>
        <div style="margin-bottom:15px;">
            <label>Nama Ruangan</label>
            <input type="text" name="nama_ruangan" class="form-control" required style="width:100%;padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <label>Nama Pengguna</label>
            <input type="text" name="nama_pengguna" class="form-control" required style="width:100%;padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <label>Keperluan</label>
            <input type="text" name="keperluan" class="form-control" required style="width:100%;padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <label>Mulai</label>
            <input type="datetime-local" name="mulai" class="form-control" required style="width:100%;padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <label>Selesai</label>
            <input type="datetime-local" name="selesai" class="form-control" required style="width:100%;padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <label>Status</label>
            <select name="status" class="form-control" required style="width:100%;padding:8px;">
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
            </select>
        </div>
        <button type="submit" style="background:#38c172;color:#fff;padding:10px 20px;border:none;border-radius:4px;">Simpan</button>
        <a href="<?php echo e(url('/')); ?>" style="margin-left:10px;">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pkbms\Documents\semester4kia\bootchamp\pertemuan1\portal-booking\resources\views/bookings/create.blade.php ENDPATH**/ ?>