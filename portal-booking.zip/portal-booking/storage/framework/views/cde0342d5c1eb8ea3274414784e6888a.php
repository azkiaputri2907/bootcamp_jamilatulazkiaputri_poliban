<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Bookings</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/booking.css')); ?>">
</head>
<body>
  <h1>Daftar Booking Ruangan</h1>
  <div style="text-align:right; margin-bottom:20px;">
    <a href="<?php echo e(route('bookings.create')); ?>" class="btn-create" style="background:#3490dc;color:#fff;padding:8px 18px;border-radius:4px;text-decoration:none;">+ Tambah Booking</a>
  </div>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Nama Ruangan</th>
        <th>Nama Pengguna</th>
        <th>Keperluan</th>
        <th>Mulai</th>
        <th>Selesai</th>
        <th>Status</th>
        <th>Dibuat</th>
        <th>Diperbarui</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($booking->id); ?></td>
        <td><?php echo e($booking->nama_ruangan); ?></td>
        <td><?php echo e($booking->nama_pengguna); ?></td>
        <td><?php echo e($booking->keperluan); ?></td>
        <td><?php echo e($booking->mulai); ?></td>
        <td><?php echo e($booking->selesai); ?></td>
        <td><?php echo e($booking->status); ?></td>
        <td><?php echo e($booking->created_at); ?></td>
        <td><?php echo e($booking->updated_at); ?></td>
        <td class="actions">
          <a href="<?php echo e(route('bookings.edit', $booking->id)); ?>" style="background:#ffc107;color:#222;padding:6px 12px;border-radius:4px;text-decoration:none;margin-right:5px;">Edit</a>
          <form action="<?php echo e(route('bookings.destroy', $booking->id)); ?>" method="POST" style="display:inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" onclick="return confirm('Yakin ingin menghapus data ini?')" style="background:#e3342f;color:#fff;padding:6px 12px;border:none;border-radius:4px;">Hapus</button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</body>
</html>
<?php /**PATH C:\Users\pkbms\Documents\semester4kia\bootchamp\pertemuan1\portal-booking\resources\views/index.blade.php ENDPATH**/ ?>