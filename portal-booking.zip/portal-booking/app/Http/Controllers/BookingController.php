<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Booking;

class BookingController extends Controller
{
    public function index()
    {
        $bookings = Booking::all();
        return view('index', compact('bookings'));
    }

    public function create()
    {
        return view('bookings.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_ruangan' => 'required',
            'nama_pengguna' => 'required',
            'keperluan' => 'required',
            'mulai' => 'required|date',
            'selesai' => 'required|date',
            'status' => 'required',
        ]);
        Booking::create($validated);
        return redirect('/')->with('success', 'Booking berhasil ditambahkan!');
    }

    public function edit($id)
    {
        $booking = Booking::findOrFail($id);
        return view('bookings.edit', compact('booking'));
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'nama_ruangan' => 'required',
            'nama_pengguna' => 'required',
            'keperluan' => 'required',
            'mulai' => 'required|date',
            'selesai' => 'required|date',
            'status' => 'required',
        ]);
        $booking = Booking::findOrFail($id);
        $booking->update($validated);
        return redirect('/')->with('success', 'Booking berhasil diupdate!');
    }

    public function destroy($id)
    {
        $booking = Booking::findOrFail($id);
        $booking->delete();
        return redirect('/')->with('success', 'Booking berhasil dihapus!');
    }
}
